using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuManager : MonoBehaviour
{
    public void PlayGame()
    {
        // GameManager ya��yorsa onu s�f�rla ki Level 1'den ba�las�n
        if (GameManager.Instance != null)
        {
            GameManager.Instance.currentLevelIndex = 1;
            // Di�er resetlemeler GameManager'�n Start'�nda veya Level y�klendi�inde yap�l�r
        }

        // Oyun Sahnesini Y�kle (Sahne ad�n "GameLevel_1" ise onu yaz, de�ilse Build Settings'den bak)
        // Seninle "GameLevel1" veya benzeri bir isimde karar k�lm��t�k.
        // E�er build settings'de index 1 ise direkt 1 de yazabilirsin.
        SceneManager.LoadScene(1);
    }

    public void QuitGame()
    {
        Debug.Log("Oyundan ��k�ld�!");
        Application.Quit();
    }
}