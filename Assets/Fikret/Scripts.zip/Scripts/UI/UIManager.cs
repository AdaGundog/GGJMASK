using UnityEngine;
using UnityEngine.SceneManagement;

public class UIManager : MonoBehaviour
{
    [Header("Oyun ��i Panelleri")]
    public GameObject infoPanel;      // Para vb. bilgilerin oldu�u panel (Info_Panel)
    public GameObject actionsPanel;   // Butonlar�n oldu�u panel (Actions_Panel)

    [Header("Oyun Sonu Panelleri")]
    public GameObject victoryPanel;
    public GameObject defeatPanel;

    private void Start()
    {
        // 1. Oyun Ba�larken:
        if (infoPanel) infoPanel.SetActive(true);       // Para g�r�ns�n
        if (actionsPanel) actionsPanel.SetActive(true); // Butonlar g�r�ns�n

        // Oyun sonu ekranlar� gizli olsun
        if (victoryPanel) victoryPanel.SetActive(false);
        if (defeatPanel) defeatPanel.SetActive(false);

        // 2. Olaylara Abone Ol
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnBattleStarted += OnBattleStarted;
            GameManager.Instance.OnVictory += OnVictory;
            GameManager.Instance.OnDefeat += OnDefeat;
        }
    }

    private void OnDestroy()
    {
        if (GameManager.Instance != null)
        {
            GameManager.Instance.OnBattleStarted -= OnBattleStarted;
            GameManager.Instance.OnVictory -= OnVictory;
            GameManager.Instance.OnDefeat -= OnDefeat;
        }
    }

    // --- OLAY Y�NET�M� ---

    private void OnBattleStarted()
    {
        // �STEK 1: Sava� ba�lay�nca sadece para kals�n, butonlar gitsin.
        if (infoPanel) infoPanel.SetActive(true);       // Para KALIYOR
        if (actionsPanel) actionsPanel.SetActive(false); // Butonlar G�D�YOR
    }

    private void OnVictory()
    {
        // �STEK 2: Oyun bitince sadece sonu� paneli kals�n.
        if (infoPanel) infoPanel.SetActive(false);     // Para G�D�YOR
        if (actionsPanel) actionsPanel.SetActive(false); // Butonlar zaten yoktu ama garanti olsun

        if (victoryPanel) victoryPanel.SetActive(true); // Sadece ZAFER A�ILIYOR
    }

    private void OnDefeat()
    {
        // �STEK 2: Oyun bitince sadece sonu� paneli kals�n.
        if (infoPanel) infoPanel.SetActive(false);     // Para G�D�YOR
        if (actionsPanel) actionsPanel.SetActive(false);

        if (defeatPanel) defeatPanel.SetActive(true);   // Sadece BOZGUN A�ILIYOR
    }

    // --- BUTON FONKS�YONLARI ---
    public void OnNextLevelClicked()
    {
        GameManager.Instance.LevelCompleted();
    }

    public void OnRetryClicked()
    {
        GameManager.Instance.RetryLevel();
    }

    public void OnMainMenuClicked()
    {
        SceneManager.LoadScene(0);
    }
}