using UnityEngine;
using UnityEngine.UI;

public class StartBattleButton : MonoBehaviour
{
    private Button myButton;

    private void Start()
    {
        myButton = GetComponent<Button>();
        // Butona t�kland���nda ne yapaca��n� kodla ba�l�yoruz (S�r�kle b�rak yok!)
        myButton.onClick.AddListener(StartTheWar);
    }

    private void StartTheWar()
    {
        // GameManager sahnede nerede olursa olsun onu bulur ve �al��t�r�r
        if (GameManager.Instance != null)
        {
            GameManager.Instance.StartBattle();
        }
        else
        {
            Debug.LogError("GameManager bulunamad�!");
        }
    }
}