using UnityEngine;
using TMPro; // TextMeshPro kullan�yoruz (Unity'nin modern yaz� sistemi)

public class MoneyUI : MonoBehaviour
{
    public TextMeshProUGUI moneyText; // Inspector'dan s�r�kle

    private void Start()
    {
        // Oyun a��l�nca paray� yaz
        UpdateMoneyUI(GameManager.Instance.CurrentMoney);

        // GameManager'daki para de�i�im eventine abone ol
        GameManager.Instance.OnMoneyChanged += UpdateMoneyUI;
    }

    private void OnDestroy()
    {
        // Obje yok olunca aboneli�i iptal et (Hata almamak i�in �art)
        if (GameManager.Instance != null)
            GameManager.Instance.OnMoneyChanged -= UpdateMoneyUI;
    }

    private void UpdateMoneyUI(int amount)
    {
        moneyText.text = "Gold: " + amount.ToString();
    }
}