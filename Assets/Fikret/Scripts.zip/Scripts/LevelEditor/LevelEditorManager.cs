using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace LevelEditor
{
    public class LevelEditorManager : MonoBehaviour
    {
        [Header("Editor Tools")]
        public bool isEditMode = false; // Bunu a��nca �izim yapaca��z

        public EnemyType currentSelection = EnemyType.Infantry;

        [Header("Level Settings")]
        public string levelFileName = "Level_1";
        public float initialInk = 100f;

        [Header("References")]
        public GameObject archerPrefab;
        public GameObject infantryPrefab;
        public GameObject cavalryPrefab;
        public Transform enemiesParent;

        // D��man verilerini tutan liste
        [HideInInspector] // Inspector'da kalabal�k etmesin, zaten �izerek g�r�yoruz
        public LevelData currentLevelData = new LevelData();

        // --- ED�T�R�N �A�IRACA�I FONKS�YON ---
        public void AddEnemyFromEditor(Vector3 position)
        {

            position.z = 0; // 2D d�zeltmesi
            GameObject prefabToUse = null;

            switch (currentSelection)
            {
                case EnemyType.Infantry: prefabToUse = infantryPrefab; break;
                case EnemyType.Cavalry: prefabToUse = cavalryPrefab; break;
                case EnemyType.Archer: prefabToUse = archerPrefab; break;
            }

            if (prefabToUse == null)
            {
                Debug.LogError($"Hata: {currentSelection} i�in Prefab atanmam��!");
                return;
            }
            // 1. G�rsel Obje Olu�tur
            // PrefabUtility.InstantiatePrefab kullan�m�, objenin "Prefab ba�lant�s�n�" korur.
            GameObject newEnemy = (GameObject)PrefabUtility.InstantiatePrefab(prefabToUse);
            newEnemy.transform.position = position;
            newEnemy.transform.parent = enemiesParent;
            newEnemy.name = $"Enemy_{currentSelection}_{currentLevelData.enemies.Count}";

            // UNDO (Geri Alma) ��lemi Kayd�
            // Buna Ctrl+Z dendi�inde objeyi silmesini sa�lar.
            Undo.RegisterCreatedObjectUndo(newEnemy, "Create Enemy");

            // 2. Veriye Ekle
            EnemySpawnData data = new EnemySpawnData(currentSelection, position);
            currentLevelData.enemies.Add(data);

            // Sahne dosyas�n� "Kirli" (De�i�tirilmi�) olarak i�aretle ki Unity "Kaydetmek istiyor musun?" diye sorsun.
            EditorUtility.SetDirty(this);

            Debug.Log($"D��man Eklendi: {position}");
        }

        // --- KAYIT S�STEM� (De�i�medi) ---
        private string GetSavePath()
        {
            string path = Path.Combine(Application.dataPath, "Fikret/Levels");
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            return path;
        }

        public void SaveLevel()
        {
            // 1. �nce eski listeyi tamamen temizle (��nk� i�inde silinenler kalm�� olabilir)
            currentLevelData.enemies.Clear();

            // 2. Sahnedeki "EnemiesContainer" i�indeki t�m ya�ayan objeleri tek tek gez
            // (Destroy edilenler zaten hiyerar�iden gitmi� oluyor)
            if (enemiesParent != null)
            {
                foreach (Transform child in enemiesParent)
                {
                    // Objenin isminden veya tag'inden tipini anlayabiliriz.
                    // Ama �imdilik basit bir y�ntem kullanal�m: Objenin ad�na bakarak tipini bulal�m.
                    // (Prefab isimlerini "Enemy_Archer_..." yapm��t�k hat�rlarsan)

                    EnemyType type = EnemyType.Infantry; // Varsay�lan

                    if (child.name.Contains("Archer")) type = EnemyType.Archer;
                    else if (child.name.Contains("Cavalry")) type = EnemyType.Cavalry;
                    else if (child.name.Contains("Infantry")) type = EnemyType.Infantry;

                    // 3. Bu ya�ayan objeyi taze listeye ekle
                    currentLevelData.enemies.Add(new EnemySpawnData(type, child.position));
                }
            }

            // 4. Di�er verileri g�ncelle
            currentLevelData.levelName = levelFileName;
            currentLevelData.startingInkAmount = initialInk;

            // 5. Kaydet
            string json = JsonUtility.ToJson(currentLevelData, true);
            string fullPath = Path.Combine(GetSavePath(), levelFileName + ".json");
            File.WriteAllText(fullPath, json);

            Debug.Log($"<color=green>B�l�m Kaydedildi (G�ncel):</color> {fullPath}");

#if UNITY_EDITOR
            UnityEditor.AssetDatabase.Refresh();
#endif
        }

        public void LoadLevel()
        {
            string fullPath = Path.Combine(GetSavePath(), levelFileName + ".json");
            if (File.Exists(fullPath))
            {
                // �nce sahneyi temizle (Eski d��manlar� sil)
                if (enemiesParent != null)
                {
                    // Edit�r modunda DestroyImmediate kullan�l�r
                    for (int i = enemiesParent.childCount - 1; i >= 0; i--)
                    {
                        DestroyImmediate(enemiesParent.GetChild(i).gameObject);
                    }
                }

                string json = File.ReadAllText(fullPath);
                currentLevelData = JsonUtility.FromJson<LevelData>(json);

                // D��manlar� tekrar yarat
                foreach (var enemyData in currentLevelData.enemies)
                {
                    GameObject newEnemy = (GameObject)PrefabUtility.InstantiatePrefab(archerPrefab);
                    newEnemy.transform.position = enemyData.position;
                    newEnemy.transform.parent = enemiesParent;
                }
                Debug.Log("B�l�m Y�klendi!");
            }
        }
        // --- G�RSEL YARDIMCILAR (GIZMOS) ---
        private void OnDrawGizmos()
        {
            // Sadece Edit Mode a��ksa �izelim
            if (!isEditMode) return;

            Gizmos.color = new Color(0.5f, 0.5f, 0.5f, 0.3f); // Yar� saydam gri

            // �rnek: -10 ile +10 aras� bir alan �izelim (Oyun alan�na g�re de�i�tirebilirsin)
            // Dikey �izgiler
            for (int x = -15; x <= 15; x++)
            {
                Gizmos.DrawLine(new Vector3(x, -10, 0), new Vector3(x, 10, 0));
            }

            // Yatay �izgiler
            for (int y = -10; y <= 10; y++)
            {
                Gizmos.DrawLine(new Vector3(-15, y, 0), new Vector3(15, y, 0));
            }

            // Mevcut D��manlar�n Alt�na ��aret Koy (Daha belirgin olsun diye)
            if (currentLevelData != null && currentLevelData.enemies != null)
            {
                foreach (var enemy in currentLevelData.enemies)
                {
                    // Asker tipine g�re renk verelim
                    switch (enemy.type)
                    {
                        case EnemyType.Infantry: Gizmos.color = Color.red; break;
                        case EnemyType.Archer: Gizmos.color = Color.green; break;
                        case EnemyType.Cavalry: Gizmos.color = Color.blue; break;
                    }
                    // Askerin oldu�u yere tel kafes �iz
                    Gizmos.DrawWireCube(enemy.position, Vector3.one);
                }
            }
        }
    }
}