using System.Collections.Generic;
using UnityEngine;

// D��man tiplerini string yerine Enum ile tutmak hatay� �nler ve performans� art�r�r.
public enum EnemyType
{
    Infantry, // Yaya
    Archer,   // Ok�u
    Cavalry   // Atl�
}

[System.Serializable] // Unity'nin bu s�n�f� Inspector'da g�sterebilmesi ve JSON'a �evirebilmesi i�in �art.
public class EnemySpawnData
{
    public EnemyType type; // D��man�n tipi
    public Vector2 position; // Sahnedeki konumu (2D)

    // Constructor: Yeni bir veri olu�tururken kolayl�k sa�lar
    public EnemySpawnData(EnemyType _type, Vector2 _pos)
    {
        type = _type;
        position = _pos;
    }
}

[System.Serializable]
public class LevelData
{
    public string levelName; // B�l�m�n ad�
    public float startingInkAmount; // Oyuncunun ba�lang��taki boya miktar�
    public List<EnemySpawnData> enemies; // O b�l�mdeki t�m d��manlar�n listesi

    // Constructor listeyi bo� ba�lat�r ki "Null Reference" hatas� almayal�m.
    public LevelData()
    {
        enemies = new List<EnemySpawnData>();
    }
}