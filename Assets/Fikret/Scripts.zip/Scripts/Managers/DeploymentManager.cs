using UnityEngine;
using System.Collections.Concurrent;
using LevelEditor;
using System;

public class DeploymentManager : MonoBehaviour
{
    [Header("Settings")]
    public LayerMask placementLayer; // Zemin (Ground) layer'�
    public Collider2D spawnZoneCollider; // Az �nce yaratt���m�z kutu

    [Header("Unit Prefabs")]
    // Developer A'n�n haz�rlad��� ger�ek askerler buraya gelecek
    public GameObject infantryPrefab;
    public GameObject archerPrefab;
    public GameObject cavalryPrefab;

    [Header("Visuals")]
    public Transform ghostObject; // Mouse'un ucundaki yar� saydam asker

    private GameObject selectedPrefab; // �u an hangisini se�tik?

    [Header("Unit Costs")]
    public int infantryCost = 50;
    public int archerCost = 75;
    public int cavalryCost = 120;

    private int currentSelectedCost = 0;    
    private void Start()
    {
        // Ba�lang��ta hayalet kapal�
        if (ghostObject) ghostObject.gameObject.SetActive(false);
        SpawnVeterans();
    }

    private void SpawnVeterans()
    {
        if (GameManager.Instance.veterans.Count > 0)
        {
            Debug.Log("Gaziler sahneye yerle�tiriliyor...");

            Vector3 spawnStartPos = spawnZoneCollider.bounds.center;
            spawnStartPos.x -= spawnZoneCollider.bounds.extents.x * 0.8f;
            int index = 0;

            foreach (VeteranData vet in GameManager.Instance.veterans)
            {
                GameObject prefabToSpawn = null;

                switch (vet.type)
                {
                    case EnemyType.Infantry: prefabToSpawn = infantryPrefab; break;
                    case EnemyType.Archer: prefabToSpawn = archerPrefab; break;
                    case EnemyType.Cavalry: prefabToSpawn = cavalryPrefab; break;
                }
                if (prefabToSpawn != null)
                {
                    Vector3 pos = spawnStartPos + new Vector3((index % 5) * 1.5f, (index / 5) * -1.5f, 0);
                    Instantiate(prefabToSpawn, pos, Quaternion.identity);
                }
                index++;
            }
        }
    }

    private void Update()
    {
        // E�er sava� ba�lad�ysa art�k yerle�tirme yapamay�z, scripti kapat.
        if (GameManager.Instance.CurrentState != GameState.Battle)
        {
            HandlePlacementInput();
        }
        else
        {
            // Sava� ba�lad�ysa hayaleti gizle ve ��k
            if (ghostObject) ghostObject.gameObject.SetActive(false);
            this.enabled = false;
        }
    }

    // UI Butonlar� bu fonksiyonu �a��racak
    public void SelectUnitToPlace(string unitType)
    {
        switch (unitType)
        {
            case "Infantry": 
                selectedPrefab = infantryPrefab;
                currentSelectedCost = infantryCost;
                break;
            case "Archer": 
                selectedPrefab = archerPrefab; 
                currentSelectedCost = archerCost;
                break;
            case "Cavalry": 
                selectedPrefab = cavalryPrefab; 
                currentSelectedCost = cavalryCost;
                break;
        }

        // Hayaleti a� (�leride sprite'�n� da se�ili askere g�re de�i�tirebiliriz)
        if (ghostObject) ghostObject.gameObject.SetActive(true);
        Debug.Log($"Se�ildi: {unitType} - Fiyat: {currentSelectedCost}");
    }

    private void HandlePlacementInput()
    {
        if (selectedPrefab == null) return;

        // 1. Mouse Pozisyonunu Bul
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = 0;

        // 2. Hayaleti Mouse'a Yap��t�r (G�rsel Yard�mc�)
        if (ghostObject) ghostObject.position = mousePos;

        // 3. T�klama Kontrol�
        if (Input.GetMouseButtonDown(0))
        {
            // Sadece Spawn Zone i�indeyse izin ver
            if (spawnZoneCollider.OverlapPoint(mousePos))
            {
                if (GameManager.Instance.SpendMoney(currentSelectedCost))
                {
                    SpawnUnit(mousePos);
                }
                else
                {
                    Debug.Log("Yetersiz Bakiye");
                }
            }
            else
            {
                Debug.Log("Bu alana asker koyamazs�n!");
                // Buraya "Hata Sesi" veya k�rm�z� yan�p s�nme efekti ekleyebilirsin.
            }
        }

        // Sa� T�k ile se�imi iptal et
        if (Input.GetMouseButtonDown(1))
        {
            selectedPrefab = null;
            if (ghostObject) ghostObject.gameObject.SetActive(false);
        }
    }

    private void SpawnUnit(Vector3 position)
    {
        // Askeri Yarat
        Instantiate(selectedPrefab, position, Quaternion.identity);

        // �leride buraya "Para D��me" veya "Limit Azaltma" kodu ekleyece�iz.
        // �imdilik s�n�rs�z koyal�m.
    }
}