using UnityEngine;
using LevelEditor;
public class UnitRegistration : MonoBehaviour
{
    [Tooltip("Bu birim oyuncunun askeri mi? (De�ilse D��man say�l�r)")]
    public bool isPlayerUnit = true;
    public EnemyType unitType;

    private void Start()
    {
        // Do�ar do�maz kendini listeye yazd�r
        if (UnitManager.Instance != null)
        {
            UnitManager.Instance.RegisterUnit(this.gameObject, isPlayerUnit);
        }
    }

    private void OnDestroy()
    {
        // �l�nce veya yok olunca listeden ad�n� sildir
        if (UnitManager.Instance != null)
        {
            UnitManager.Instance.UnregisterUnit(this.gameObject, isPlayerUnit);
        }
    }
}