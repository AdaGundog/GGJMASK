using System.Collections.Generic;
using System.IO;
using UnityEngine;
using LevelEditor; // LevelData ve EnemyData'ya eri�mek i�in

public class LevelLoader : MonoBehaviour
{
    // public string levelFileNameToLoad = "Level_1"; <-- BU ARTIK YOK (Otomatik)

    [Header("Game Prefabs (Real Units)")]
    public GameObject realInfantryPrefab;
    public GameObject realArcherPrefab;
    public GameObject realCavalryPrefab;

    [Header("Runtime References")]
    public Transform gameUnitsParent;

    private void Start()
    {
        LoadLevelAndSpawn();
    }

    private void LoadLevelAndSpawn()
    {
        // --- D�NAM�K DOSYA ADI ---
        // GameManager'daki say�ya g�re dosya ad�n� olu�turuyoruz: Level_1, Level_2 vs.
        string currentFileName = "Level_" + GameManager.Instance.currentLevelIndex;

        // Dosya Yolunu Bul (Senin klas�r yap�na uygun: Fikret/Levels)
        string savePath = Path.Combine(Application.dataPath, "Fikret/Levels");
        string fullPath = Path.Combine(savePath, currentFileName + ".json");

        if (!File.Exists(fullPath))
        {
            Debug.LogError($"KR�T�K HATA: B�l�m dosyas� bulunamad�! Yol: {fullPath}");
            Debug.LogWarning("Oyun bitmi� olabilir veya hen�z bu level �izilmemi�.");
            return;
        }

        // Dosyay� Oku
        string json = File.ReadAllText(fullPath);
        LevelData data = JsonUtility.FromJson<LevelData>(json);

        Debug.Log($"B�l�m Y�kleniyor: {currentFileName} (M�rekkep: {data.startingInkAmount})");

        // Askerleri Do�ur (Spawn)
        foreach (var enemyData in data.enemies)
        {
            SpawnUnit(enemyData);
        }
    }

    private void SpawnUnit(EnemySpawnData data)
    {
        GameObject prefabToUse = null;

        switch (data.type)
        {
            case EnemyType.Infantry: prefabToUse = realInfantryPrefab; break;
            case EnemyType.Archer: prefabToUse = realArcherPrefab; break;
            case EnemyType.Cavalry: prefabToUse = realCavalryPrefab; break;
        }

        if (prefabToUse != null)
        {
            Vector3 spawnPos = new Vector3(data.position.x, data.position.y, 0);
            GameObject unit = Instantiate(prefabToUse, spawnPos, Quaternion.identity, gameUnitsParent);

            unit.name = $"Enemy_{data.type}";

            // --- YEN� EKLENEN KISIM: K�ML�K ZORLAMASI ---
            // Yarat�lan objenin �zerindeki kimlik kart�n� bul
            UnitRegistration reg = unit.GetComponent<UnitRegistration>();
            if (reg != null)
            {
                // "Sen oyuncu de�ilsin, sen d��mans�n!" de.
                reg.isPlayerUnit = false;
                reg.unitType = data.type; // Tipini de garantiye alal�m
            }
            // ---------------------------------------------
        }
    }
}